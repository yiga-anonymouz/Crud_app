
USER MANAGEMENT SYSTEM

A simple web app that gets the list of users registered to the app and their information(gender , email and status) and also makes changes or delete a user
