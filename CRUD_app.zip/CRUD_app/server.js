const express = require('express')
const https = require('https')
const bodyParser = require('body-parser')
const mongoose = require('mongoose')

const app = express()
app.set('view engine', 'ejs')
app.use(bodyParser.urlencoded({ extended: true }))
app.use(express.static(`${__dirname}/public`));
mongoose.connect('mongodb://localhost:27017/ums')

let customers = []

// https.get('https://api.openweathermap.org/data/2.5/weather?lat=44.34&lon=10.99&appid=5b7494bfba6561483ff193b9a5b88d7b&units=metric', (response) => {
//     response.on('data', (data) => {
//         const weatherData = JSON.parse(data)
//         console.log(weatherData.weather[0].main)
//     })
    
// })

const userSchema = {
    name: String,
    email: String,
    gender: String,
    status: String,
    modified: Boolean
}

const Users = mongoose.model('User', userSchema)

// users.insertMany(userone, (err , res) => {
//     if(err){
//         console.log('STFU bitch')
//     }else{
//         console.log('saved succesfullly')
//     }
// })

app.post('/' , (req, res) => {
    const inputData = {
        name: req.body.name,
        email: req.body.email,
        gender: req.body.gender,
        status: req.body.status,
        modified: false
    }
    const inputs = new Users(inputData);
    
    inputs.save()

    res.redirect('/')
})

app.post('/delete' , (req , res) => {
    console.log(req.body)
    const deletedId = req.body.deleted

    Users.findByIdAndRemove(deletedId, (err) => {
        if(err){
            console.log('Ha ha')
        }else{
            console.log('successful')
            res.redirect('/')
        }
    })
})


app.get('/', (req, res) => {
    Users.find({'id': 1}, (err, userDatas) => {
        res.render('ums', {userDAta : userDatas})
    })
})


app.listen('3000', () =>{
    console.log('Server started')
})